## 2021-tgthon

__+ 아두이노를 이용한 현관 출입자 감시 장치__

------------------------

### 실행파일: MyCCTV.ino
### 라이브러리 수정 파일: SD.h , SD.cpp

* 실행 방법
1. 라이브러리 다운로드
2. SD.h , SD.cpp 파일 교체
3. MyCCTV.ino 에서 공유기 SSID와 PASSWORD를 입력

* 사전 설정
1. IP DDNS 등록
2. 포트 포워딩 설정(포트번호: 80) 


ex) MyCCTV.iptime.org/capture  : 사진 모드  
    MyCCTV.iptime.org/stream   : 영상 모드

_- 18 박선홍_ <br />
_- 18 김진우_ <br />
_- 19 유영빈_ <br />
_- 21 정용준_
